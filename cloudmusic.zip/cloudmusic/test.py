import json
import pandas as pd
import matplotlib.pyplot as plt

# 读取JSON文件
with open('response.json', 'r', encoding='utf-8') as file:
    data = json.load(file)

# 假设数据是一个列表，每个元素代表一首歌曲
df = pd.DataFrame(data)

# 选择要可视化的列，例如：歌曲名称和时长
df['song_time'] = pd.to_timedelta(df['song_time'])  # 转换时长格式
df['music_name'] = df['music_name'].astype(str)  # 确保歌曲名称是字符串

# 绘制歌曲时长的条形图
plt.figure(figsize=(12, 6))
plt.bar(df['music_name'][:10], df['song_time'].dt.total_seconds()[:10])  # 只绘制前10首歌
plt.xlabel('Song Name')
plt.ylabel('Duration (seconds)')
plt.title('Top 10 Songs Duration')
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()
